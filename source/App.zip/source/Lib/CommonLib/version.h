#if ! defined( VTM_VERSION )
#define VTM_VERSION "18.0"
#endif
